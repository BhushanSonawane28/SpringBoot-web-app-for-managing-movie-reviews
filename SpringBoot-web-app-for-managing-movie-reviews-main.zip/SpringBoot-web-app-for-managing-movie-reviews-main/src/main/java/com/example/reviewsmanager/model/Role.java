package com.example.reviewsmanager.model;

public enum Role
{
    USER,
    ADMIN
}
