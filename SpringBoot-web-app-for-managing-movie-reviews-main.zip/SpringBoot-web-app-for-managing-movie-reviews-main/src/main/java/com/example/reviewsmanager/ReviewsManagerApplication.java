package com.example.reviewsmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewsManagerApplication
{
    public static void main(String[] args)
    {
        SpringApplication.run(ReviewsManagerApplication.class, args);
    }
}
